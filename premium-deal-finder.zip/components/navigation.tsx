"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Plane, Search, Bell, User, Menu, FlaskConical } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { LogoutButton } from "@/components/logout-button"
import { cn } from "@/lib/utils"
import { useJourney } from "@/lib/contexts/journey-context"

interface NavigationProps {
  isLoggedIn?: boolean
}

export function Navigation({ isLoggedIn = false }: NavigationProps) {
  const pathname = usePathname()
  const { isDemoMode, startJourney, enableDemo } = useJourney()

  const handleStartDemo = () => {
    enableDemo()
    startJourney()
  }

  const navItems = [
    { href: "/", label: "Deals", icon: Search },
    { href: "/guide", label: "Guide", icon: null },
  ]

  const userNavItems = isLoggedIn
    ? [
        { href: "/dashboard", label: "Dashboard", icon: User },
        { href: "/dashboard/watchlists", label: "Watchlists", icon: Bell },
        { href: "/dashboard/alerts", label: "Alerts", icon: Bell },
      ]
    : []

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Plane className="h-5 w-5" />
          </div>
          <span className="font-space">Premium Deal Finder</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                pathname === item.href ? "text-foreground" : "text-muted-foreground",
              )}
            >
              {item.label}
            </Link>
          ))}
          {userNavItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                pathname === item.href ? "text-foreground" : "text-muted-foreground",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          {!isDemoMode && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleStartDemo}
              className="hidden md:flex"
            >
              <FlaskConical className="h-4 w-4 mr-2" />
              Try Demo
            </Button>
          )}
          {isLoggedIn ? (
            <div className="hidden md:flex items-center gap-2">
              <Button asChild variant="outline">
                <Link href="/dashboard">
                  <User className="h-4 w-4 mr-2" />
                  Dashboard
                </Link>
              </Button>
              <LogoutButton />
            </div>
          ) : (
            <>
              <Button asChild variant="ghost" className="hidden md:flex">
                <Link href="/login">Login</Link>
              </Button>
              <Button asChild className="hidden md:flex">
                <Link href="/signup">Sign Up</Link>
              </Button>
            </>
          )}

          {/* Mobile Navigation */}
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right">
              <div className="flex flex-col gap-4 mt-8">
                {navItems.concat(userNavItems).map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "text-sm font-medium transition-colors hover:text-primary py-2",
                      pathname === item.href ? "text-foreground" : "text-muted-foreground",
                    )}
                  >
                    {item.label}
                  </Link>
                ))}
                {!isDemoMode && (
                  <Button
                    variant="outline"
                    onClick={handleStartDemo}
                    className="justify-start"
                  >
                    <FlaskConical className="h-4 w-4 mr-2" />
                    Try Demo
                  </Button>
                )}
                {isLoggedIn ? (
                  <LogoutButton />
                ) : (
                  <>
                    <Button asChild variant="ghost" className="justify-start">
                      <Link href="/login">Login</Link>
                    </Button>
                    <Button asChild className="justify-start">
                      <Link href="/signup">Sign Up</Link>
                    </Button>
                  </>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
