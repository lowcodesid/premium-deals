"use client"

import { useJourney } from "@/lib/contexts/journey-context"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { CheckCircle, Sparkles } from "lucide-react"
import Link from "next/link"

export function JourneyCompleteModal() {
  const { currentStep, skipJourney } = useJourney()

  if (currentStep !== "complete") return null

  return (
    <Dialog open={true} onOpenChange={() => skipJourney()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-accent to-primary animate-pulse">
              <CheckCircle className="h-8 w-8 text-primary-foreground" />
            </div>
          </div>
          <DialogTitle className="text-2xl font-space">{"You're"} All Set!</DialogTitle>
          <DialogDescription className="text-base leading-relaxed">
            You now know how to find and compare premium flight deals. Start exploring to find your next adventure!
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-3">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted">
            <Sparkles className="h-5 w-5 text-primary" />
            <div>
              <p className="font-medium text-sm">Pro Tip</p>
              <p className="text-xs text-muted-foreground">
                Create a watchlist to get notified when deals match your preferred routes!
              </p>
            </div>
          </div>
        </div>

        <DialogFooter className="flex-col gap-2 sm:flex-col">
          <Button onClick={skipJourney} className="w-full">
            Start Exploring
          </Button>
          <Button asChild variant="outline" className="w-full">
            <Link href="/dashboard/watchlists/new">Create Your First Watchlist</Link>
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
